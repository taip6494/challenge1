package com.example.challenge1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
